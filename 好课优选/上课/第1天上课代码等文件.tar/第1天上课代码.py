
# 找一个网址 以字符串的形式保存在一个变量中！
url = "https://v26-web.douyinvod.com/351620a280feb6dc9002423f7a76fa5a/63d7cbeb/video/tos/cn/tos-cn-ve-15/owmt7LiA9okAJNfbClQg4znjYIueDAmwBgiAAs/?a=6383&ch=54&cr=3&dr=0&lr=all&cd=0%7C0%7C0%7C3&cv=1&br=998&bt=998&cs=0&ds=3&ft=LjhJEL998xIouEkmD0P5H4eaciDXtks0d5QEeg-czijD1Ini&mime_type=video_mp4&qs=0&rc=ZDM5aTY1ZjRpM2U7PDZnOkBpanc6OjQ6ZjxqaDMzNGkzM0BjMS4yNmA1NTUxYzY2XzRfYSNvYTA2cjRnLW1gLS1kLWFzcw%3D%3D&l=202301302053005280D9206CC8081A59C4&btag=20000"

# 导入请求模块 一定要先安装！
import requests

# 使用requests的get功能 获取网站的响应
res = requests.get(url)

# 打开一个空的视频(真·狗粮.mp4) 把得到res.content丢进去 得到一个可以播放的视频
open('美女1.mp4', 'wb').write(res.content)

# 1.什么叫做爬虫！
# 基本流程
# 短视频 基本上都可以！
# 作业！

# 90% python 爬虫迷惑住了！
# 网站开发  互站网！
# 数据分析  审计 财务 电商 金融 股票 人事 行政 银行
# 人工智障  特斯拉 华为 大疆.... 摄像头+图像识别+算法
# 脚本外挂  黑客

# 最后2个事情！6666
# 1.找让你来听课的小班老师 预约明天晚上的课程！
#     预约的同学：专属解答群！

# 2.加我好友  作业：完成今晚讲的这4行代码！爬取一个好看的视频给我！
#  奖励：VIP音乐爬虫 + VIP视频解析 + 腾讯QQ小游戏外挂！






